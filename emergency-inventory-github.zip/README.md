# 救急物品 在庫管理アプリ

職場で使用する救急物品の在庫を管理するためのWebアプリです。

## 主な機能

- 物品マスタ登録
- 在庫一覧、物品名検索、カテゴリ絞り込み、保管場所絞り込み
- 状態フィルターによる不足一覧表示
- 受入・払出の記録
- 受払履歴の一覧表示
- CSVインポート、CSVエクスポート
- サーバー版で複数端末から同じデータを共有

## ローカルで使う

`index.html` をダブルクリックすると、ブラウザだけで使えます。

この場合、データはその端末のブラウザ内に保存されます。

## サーバー版として使う

Node.jsをインストールしたパソコンで、次のどちらかを実行します。

Windowsの場合:

```bat
start-server.bat
```

または:

```bash
npm start
```

起動後、親機では次のURLを開きます。

```text
http://localhost:8080
```

同じネットワーク内の別端末からは、起動画面に表示されるURLを開きます。

```text
http://親機のIPアドレス:8080
```

## GitHubに置く

初回だけ次の手順でGitHubへアップロードします。

```bash
git init
git add .
git commit -m "Initial emergency inventory app"
git branch -M main
git remote add origin https://github.com/ユーザー名/リポジトリ名.git
git push -u origin main
```

## Renderなどで公開する

GitHubにアップロードしたあと、Renderなどのホスティングサービスでこのリポジトリを接続します。

設定例:

- Build Command: 空欄または `npm install`
- Start Command: `npm start`
- Runtime: Node.js

## セキュリティ注意

現在のサーバー版にはログイン機能がありません。

職場内ネットワークでの簡易利用向けです。インターネット公開する場合は、ログイン機能、HTTPS、アクセス制限、バックアップを追加してください。
