const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");

const PORT = Number(process.env.PORT) || 8080;
const ROOT = __dirname;
const DATA_FILE = path.join(ROOT, "inventory-data.json");

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".csv": "text/csv; charset=utf-8"
};

function defaultState() {
  return { items: [], history: [] };
}

function readState() {
  if (!fs.existsSync(DATA_FILE)) return defaultState();
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    return {
      items: Array.isArray(data.items) ? data.items : [],
      history: Array.isArray(data.history) ? data.history : []
    };
  } catch {
    return defaultState();
  }
}

function writeState(state) {
  const safeState = {
    items: Array.isArray(state.items) ? state.items : [],
    history: Array.isArray(state.history) ? state.history : []
  };
  fs.writeFileSync(DATA_FILE, JSON.stringify(safeState, null, 2), "utf8");
}

function sendJson(response, status, payload) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  response.end(JSON.stringify(payload));
}

function receiveJson(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 10 * 1024 * 1024) {
        reject(new Error("request too large"));
        request.destroy();
      }
    });
    request.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch (error) {
        reject(error);
      }
    });
    request.on("error", reject);
  });
}

function serveFile(request, response) {
  const requestUrl = new URL(request.url, `http://${request.headers.host}`);
  const pathname = decodeURIComponent(requestUrl.pathname);
  const filePath = path.normalize(path.join(ROOT, pathname === "/" ? "index.html" : pathname));

  if (!filePath.startsWith(ROOT) || filePath === DATA_FILE) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (error, content) => {
    if (error) {
      response.writeHead(404);
      response.end("Not Found");
      return;
    }

    response.writeHead(200, {
      "Content-Type": MIME_TYPES[path.extname(filePath)] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    response.end(content);
  });
}

const server = http.createServer(async (request, response) => {
  if (request.url === "/api/state" && request.method === "GET") {
    sendJson(response, 200, readState());
    return;
  }

  if (request.url === "/api/state" && request.method === "POST") {
    try {
      const state = await receiveJson(request);
      writeState(state);
      sendJson(response, 200, { ok: true });
    } catch {
      sendJson(response, 400, { ok: false, message: "保存できませんでした" });
    }
    return;
  }

  if (request.method === "GET") {
    serveFile(request, response);
    return;
  }

  response.writeHead(405);
  response.end("Method Not Allowed");
});

server.listen(PORT, "0.0.0.0", () => {
  const addresses = Object.values(os.networkInterfaces())
    .flat()
    .filter((entry) => entry && entry.family === "IPv4" && !entry.internal)
    .map((entry) => `http://${entry.address}:${PORT}`);

  console.log("救急物品 在庫管理サーバーを起動しました。");
  console.log(`このパソコン: http://localhost:${PORT}`);
  addresses.forEach((address) => console.log(`他の端末: ${address}`));
});
